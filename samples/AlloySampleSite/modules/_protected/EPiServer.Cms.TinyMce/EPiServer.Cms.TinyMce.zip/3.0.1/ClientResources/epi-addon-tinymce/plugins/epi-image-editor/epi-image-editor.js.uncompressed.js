define("epi-addon-tinymce/plugins/epi-image-editor/epi-image-editor", [
    "epi-addon-tinymce/tinymce-loader",
    "epi-cms/command/EditImage",
    "epi/i18n!epi/cms/nls/episerver.cms.tinymce.plugins.epiimageeditor"
], function (
    tinymce,
    EditImage,
    pluginResources
) {

    tinymce.PluginManager.add("epi-image-editor", function (editor) {

        var imageNode;

        editor.addCommand("epiImageEditor", function () {

            // tinymce does store bookmark when opening a window but only for browser IE or inline editor
            // therefore, in general we need to store the bookmark ourselves
            var bookmark = editor.selection.getBookmark();

            function onHide() {
                editor.selection.moveToBookmark(bookmark);
                editor.fire("CloseWindow", {
                    win: null
                });
            }

            function onCallback(callbackObject) {
                editor.selection.moveToBookmark(bookmark);
                editor.selection.setNode(callbackObject);
            }

            editor.fire("OpenWindow",
                {
                    win: null
                });
            EditImage.prototype.showImageEditorDialog(imageNode, onHide, onCallback);
        });

        // Register buttons
        editor.addButton("epi-image-editor", {
            title: pluginResources.title,
            cmd: "epiImageEditor",
            icon: "editimage",
            onPostRender: function () {
                // Add a node change handler, selects the button in the UI when a image is selected
                editor.on("NodeChange", function (e) {
                    //Prevent tool from being activated as objects represented as images.
                    var isStandardImage = e.element.tagName === "IMG" && editor.dom.getAttrib(e.element, "class").indexOf("mceItem") === -1;
                    var isImageFigure = e.element.tagName === "FIGURE" && /\bimage\b/i.test(e.element.className);
                    this.active(isStandardImage || isImageFigure);
                    this.disabled(!isStandardImage && !isImageFigure);

                    //Set or reset imageNode to the node cause Image Editor command enabled
                    imageNode = isStandardImage ? e.element : isImageFigure ? editor.dom.select("img", e.element)[0] : null;
                }.bind(this));
            }
        });

        return {
            getMetadata: function () {
                return {
                    name: "Image Editor (epi)",
                    url: "https://www.episerver.com"
                };
            }
        };
    });
});
