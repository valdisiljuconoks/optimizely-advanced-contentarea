define("epi-cms/contentediting/command/BlockInlinePublish", [
    "dojo/_base/declare",
    "epi-cms/contentediting/command/Publish",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/command/_BlockInlineCommandMixin",

    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.inlineediting.inlinecommands.inlinepublish"
], function (
    declare,
    Publish,
    ContentActionSupport,
    _BlockInlineCommandMixin,
    res
) {

    return declare([Publish, _BlockInlineCommandMixin], {
        // summary:
        //      Inline publish content command.
        // tags:
        //      internal xproduct

        errorMessageHeading: res.error,

        successMessage: res.success,

        requiredAction: ContentActionSupport.action.Publish,

        ignoredStatuses: [
            ContentActionSupport.versionStatus.DelayedPublish,
            ContentActionSupport.versionStatus.Published,
            ContentActionSupport.versionStatus.Expired,
            ContentActionSupport.versionStatus.AwaitingApproval
        ]
    });
});
