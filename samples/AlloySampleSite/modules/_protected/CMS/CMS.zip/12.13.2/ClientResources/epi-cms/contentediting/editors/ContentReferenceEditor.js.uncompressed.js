require({cache:{
'url:epi-cms/contentediting/editors/templates/ContentReferenceEditor.html':"<div class=\"dijitInline\" tabindex=\"-1\" role=\"presentation\">\r\n    <div class=\"epi-content-reference-header-block\">\r\n        <div data-dojo-attach-point=\"allowedTypesHeader\"></div>\r\n    </div>\r\n    <div data-dojo-attach-point=\"contentSelectorContainer\" />\r\n</div>"}});
define("epi-cms/contentediting/editors/ContentReferenceEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/dom-class",
    "dojo/aspect",

    // dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",
    "dijit/_WidgetsInTemplateMixin",

    // epi.shell
    "epi/shell/widget/_ValueRequiredMixin",
    "epi/shell/widget/_FocusableMixin",

    // epi.cms
    "epi-cms/core/ContentReference",
    "epi-cms/widget/_ContentSelectorActionsMixin",
    "epi-cms/widget/ContentSelector",
    "epi-cms/widget/MediaSelector",
    "epi-cms/widget/ThumbnailSelector",
    "epi-cms/contentediting/AllowedTypesList",

    // resources
    "epi/i18n!epi/cms/nls/episerver.cms.widget.contentselector",
    "dojo/text!./templates/ContentReferenceEditor.html"
], function (
    // dojo
    declare,
    domClass,
    aspect,

    _TemplatedMixin,
    _WidgetBase,
    _WidgetsInTemplateMixin,

    // epi.shell
    _ValueRequiredMixin,
    _FocusableMixin,

    // epi.cms
    ContentReference,
    _ContentSelectorActionsMixin,
    ContentSelector,
    MediaSelector,
    ThumbnailSelector,
    AllowedTypesList,

    // resources
    localization,
    template
) {

    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, _ValueRequiredMixin, _FocusableMixin], {
        // summary:
        //    Represents the widget to select ContentReference.
        // tags:
        //      internal xproduct

        templateString: template,

        baseClass: "epi-content-reference-wrapper",

        contentSelector: null,

        value: null,

        postMixInProperties: function () {
            // summary:
            //		Initialize properties
            // tags:
            //    protected

            this.inherited(arguments);

            var _contentSelectorType = this._getContentSelectorType();
            this.contentSelector = new _contentSelectorType(this.params);

            this.allowedTypesList = new AllowedTypesList({
                defaultAllowedTypes: this.defaultAllowedTypes,
                allowedTypes: this.allowedTypes,
                restrictedTypes: this.restrictedTypes
            });

            this.own(
                this.contentSelector,
                this.allowedTypesList
            );
        },

        buildRendering: function () {
            // summary:
            //		Creates and append the input hidden field to the dom to preserve the contentLink id
            // tags:
            //    protected

            this.inherited(arguments);

            this.contentSelector.placeAt(this.contentSelectorContainer);

            this.allowedTypesList.placeAt(this.allowedTypesHeader);
        },

        startup: function () {
            this.inherited(arguments);

            this._updateStyle();

            this.own(
                this.allowedTypesList.watch("hasRestriction", this._updateStyle.bind(this)),
                aspect.after(this.contentSelector, "onChange", this._contenSelectorOnChange.bind(this), true)
            );
        },

        _contenSelectorOnChange: function (contentLink) {
            if (!ContentReference.compareIgnoreVersion(this.value, contentLink)) {
                this.onFocus();
                this.value = contentLink;
                this.onChange(this.value);
                this._hasBeenBlurred = true;
                this.validate(true);
            }
        },

        validate: function (/*Boolean*/isFocused) {
            var result = this.inherited(arguments);
            return result && this.contentSelector && this.contentSelector.validate(isFocused);
        },

        focus: function () {
            this.contentSelector.focus();
        },

        _set: function (name, value) {
            this.inherited(arguments);
            this.contentSelector && this.contentSelector.set(name, value);
        },

        _get: function (name, value) {
            return this.contentSelector && this.contentSelector.get(name, value);
        },

        _getContentSelectorType: function () {
            if (this._isSelectorFor("episerver.core.icontentimage")) {
                return ThumbnailSelector;
            }

            if (this._isSelectorFor("episerver.core.icontentmedia")
                || this._isSelectorFor("episerver.core.icontentvideo")) {
                return declare([MediaSelector, _ContentSelectorActionsMixin], {});
            }

            return declare([ContentSelector, _ContentSelectorActionsMixin], {});
        },

        _isSelectorFor: function (typeIdentifier) {
            // summary:
            //      Determine which editor descriptor is used
            return this.defaultAllowedTypes && this.defaultAllowedTypes.indexOf(typeIdentifier) > -1;
        },

        _updateStyle: function () {
            // summary:
            //      Handle the widget style depending on the allowedTypesList visibility

            if (!this.domNode) {
                return;
            }

            if (this.allowedTypesList.get("hasRestriction")) {
                domClass.remove(this.domNode, "allowed-types-list-hidden");
            } else {
                domClass.add(this.domNode, "allowed-types-list-hidden");
            }
        }
    });
});
