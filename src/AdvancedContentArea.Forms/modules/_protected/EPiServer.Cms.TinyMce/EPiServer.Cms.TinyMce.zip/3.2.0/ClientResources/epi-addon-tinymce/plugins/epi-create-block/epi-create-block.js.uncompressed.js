define("epi-addon-tinymce/plugins/epi-create-block/epi-create-block", [
    "epi-addon-tinymce/tinymce-loader",
    "epi-cms/widget/command/CreateContentFromSelector",
    "epi-addon-tinymce/ContentService",
    "epi-addon-tinymce/plugins/epi-dnd-processor/dndDropProcessor",
    "epi/i18n!epi/cms/nls/episerver.cms.tinymce.plugins.epicreateblock"
], function (
    tinymce,
    CreateContentFromSelector,
    ContentService,
    DndDropProcessor,
    pluginResource) {

    tinymce.PluginManager.add("epi-create-block", function (editor) {
        // We do not allow to create local blocks in Create mode because
        // we don't have the contextual folder (For this page/block) yet
        // that could be the parent for newly created local block
        if (editor.isInCreateMode || !editor.hasCreateAccessRights) {
            return;
        }

        editor.addCommand("mceEPiCreateBlock", function () {
            var command = new CreateContentFromSelector({
                creatingTypeIdentifier: "episerver.core.blockdata",
                createAsLocalAsset: true,
                isInQuickEditMode: this.isInQuickEditMode || this.isEditing || this.isFullScreen,
                suppressOverlayAdjustments: this.isFullScreen,
                autoPublish: true
            });

            var contentService = new ContentService();

            command.set("model", {
                save: function (block) {
                    contentService.getContent(block.contentLink).then(function (model) {
                        var item = {
                            type: ["episerver.core.blockdata"],
                            data: model
                        };
                        var processor = new DndDropProcessor(editor);
                        processor.processData(item);
                    });
                }.bind(this),
                cancel: function () { }
            });
            command.execute();
        });

        editor.on("FullscreenStateChanged", function (event) {
            this.isFullScreen = event.state;
        });

        // Register buttons
        editor.addButton("epi-create-block", {
            title: pluginResource.title,
            cmd: "mceEPiCreateBlock",
            icon: " epi-iconSharedBlock",
            onPostRender: function () {
                editor.on("SelectionChange", function (e) {
                    var isTextSelected = editor.selection.getContent() !== "";
                    this.disabled(editor.readonly || isTextSelected);
                }.bind(this));
            }
        });

        editor.shortcuts.add("ctrl+l", pluginResource.title, function () {
            editor.execCommand("mceEPiCreateBlock");
        });

        return {
            getMetadata: function () {
                return {
                    name: "Create block (optimizely)",
                    url: "https://www.optimizely.com/"
                };
            }
        };
    });
});
