define("epi-addon-tinymce/FileBrowser", [
    "dojo/on",
    "dojo/dom-style",
    "dojo/when",
    "epi/dependency",
    "epi/UriParser",
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/widget/ContentSelectorDialog",

    "./tinymce-loader",

    "epi/i18n!epi/cms/nls/episerver.cms.widget.contentselector"
], function (
    on,
    domStyle,
    when,
    dependency,
    UriParser,
    Dialog,
    ContentSelectorDialog,
    tinymce,
    res
) {
    var getAllowedTypes = function (type) {
        switch (type) {
            case "image":
                return ["episerver.core.icontentimage"];
            case "media":
                return ["episerver.core.icontentmedia"];
            default:
                return ["episerver.core.pagedata"];
        }
    };

    var getFiletype = function (type) {
        switch (type) {
            case "image":
            case "media":
                return "media";
            default:
                return "pages";
        }
    };

    return function (settings, registry, store, contextStore, contentRepositoryDescriptors) {
        // summary:
        //      Adds a callback method for the file_picker_callback that makes it possible to pick
        //      content in the system using our Content Selector
        // settings: TinyMCE settings object
        //      The TinyMCE settings object to add the callback to
        //
        // returns:
        //      The settings object that was provided
        // tags:
        //      internal

        registry = registry || dependency.resolve("epi.storeregistry");
        store = store || registry.get("epi.cms.content.light");
        contextStore = contextStore || registry.get("epi.shell.context");
        contentRepositoryDescriptors = contentRepositoryDescriptors || dependency.resolve("epi.cms.contentRepositoryDescriptors");

        // By hooking up the file_picker_callback this code will inject a dialog wherever you can "pick" stuff in tiny
        settings.file_picker_types = "file image media";
        settings.file_picker_callback = function (callback, value, meta) {

            var settings = contentRepositoryDescriptors.get(getFiletype(meta.filetype));

            var contentSelector = new ContentSelectorDialog({
                canSelectOwnerContent: false,
                showButtons: false,
                roots: settings.roots,
                multiRootsMode: true,
                showRoot: true,
                allowedTypes: getAllowedTypes(meta.filetype)
            });
            var dialog = new Dialog({
                title: res.title,
                dialogClass: "epi-dialog-portrait",
                content: contentSelector
            });
            dialog.own(contentSelector);

            // Set the selected item when editing an existing file.
            if (value) {
                var result = contextStore.query({ url: value });
                when(result).then(function (context) {
                    var uri = new UriParser(context.versionAgnosticUri);
                    contentSelector.set("value", uri.getId());
                });
            }

            dialog.show();

            // We can't use our dialog service because we can't set the zIndex required to show our dialog
            // above TinyMCE dialog
            domStyle.set(dialog.domNode, "zIndex", tinymce.ui.FloatPanel.currentZIndex + 20);

            on.once(dialog, "execute", function () {
                var contentLink = contentSelector.get("value");
                if (!contentLink) {
                    return;
                }

                // Load the content object and use the preview url
                when(store.get(contentLink)).then(function (content) {
                    callback(content.previewUrl);
                });
            });
        };

        return settings;
    };
});
